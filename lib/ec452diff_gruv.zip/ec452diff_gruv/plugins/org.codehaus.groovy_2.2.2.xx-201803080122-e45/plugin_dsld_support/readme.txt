This folder contains some standard DSL descriptor files that are
specific to this version of Groovy-Eclipse and are applicable to
all projects in your workspace.  In general, you should not edit
the files here.  If you want to add custom DSLDs for your entire
workspace, then you should add them to ~/.groovy/greclipse/dsld.
